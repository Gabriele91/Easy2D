#include <stdafx.h>
#include <Easy2D.h>
using namespace Easy2D;

#include "Tank.h"

class MyGame : Game,Input::KeyboardHandler

{

	//variable declaration
	ResourcesGroup resources;	
	Render rander;
	Camera camera;

	Layer* layer1;
	Tank* tank;
	Sprite* background;
	Font::ptr gamefont;

public:

	MyGame()
	//init screen
	:Game("my game",
		  1280, //width
		  720,  //hight
		  32,   //bit
		  60,   //frame per second
		  false,//fullscreen
		  Easy2D::Screen::MSAAx4)//anti aliasing
	//init textures
	,resources("livel/resources.rs.e2d")
	{}

	~MyGame(){};
	

	virtual void start(){
		//input 
		getInput()->addHandler((Input::KeyboardHandler*)this);
		//port mode
		getScreen()->setOrientation(Easy2D::Screen::SENSOR_PORTRAIT);
		//add layers
		layer1=rander.addLayer(true);
		//resources
		gamefont=resources.load<Font>("gamefont");
		//tank
		tank=new Tank(resources);
		tank->setLayer(layer1,10);
		//backgound
		background=new Sprite();
		background->setTexture(resources.load<Texture>("background"));
		background->setZ(0);
		layer1->addRenderable(background);
		//set camera
		rander.setCamera(&camera);
		//load resources
		resources.load();
	}
	virtual void run(float dt){
		//draw:
		rander.updateProjection();
		rander.setClear(Color(64,128,255,255));			
		rander.update(dt);
		rander.draw();
        CHECK_GPU_ERRORS();
	}
	virtual void end(){
		//delete listener
		getInput()->removeHandler((Input::KeyboardHandler*)this);
		//delete tank
		delete tank;
		//delete background
		delete background;
	}

	/* OOP-STYLE EVENTS */
	virtual void onKeyRelease(Key::Keyboard key) {
		if(key==Key::ESCAPE) Application::instance()->exit();
	}

};

int main(int,const char **){

	Application::create();
	Application::instance()->exec((Game*)new MyGame());
	delete Application::instance()->getGame();
	return 0;
}

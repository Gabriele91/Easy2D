#ifndef TANK_H
#define TANK_H
#include <Easy2D.h>
using namespace Easy2D;


class Tank:    Input::KeyboardHandler,
			   Input::MouseHandler,
			   Input::FingersHandler{

	AnimatedSprite *tank;
	AnimatedSprite *tankdown;
	int animTankRotation;
	int animTankDown;
	int animTankUp;
	int animTankLeft;
	int animTankRight;
	Vec2 translation;
	float velocity;

	public:

		Tank(ResourcesGroup& resources){
			//alloc
			tank=new AnimatedSprite();
			tankdown=new AnimatedSprite();
			//animation head
			animTankRotation=tank->addAnimation(resources.load<FrameSet>("tankRotation"));
			//animation body
			animTankDown=tankdown->addAnimation(resources.load<FrameSet>("tankDown"));
			animTankUp=tankdown->addAnimation(resources.load<FrameSet>("tankUp"));
			animTankLeft=tankdown->addAnimation(resources.load<FrameSet>("tankLeft"));
			animTankRight=tankdown->addAnimation(resources.load<FrameSet>("tankRight"));
			//atach body
			tank->addChild((Object*)tankdown,Object::ENABLE_POSITION);
			//input
			Application::instance()->getInput()->addHandler((Input::KeyboardHandler*)this);
			Application::instance()->getInput()->addHandler((Input::MouseHandler*)this);
			Application::instance()->getInput()->addHandler((Input::FingersHandler*)this);
			//fake key press
			onKeyPress(Key::S);
			tankdown->setTime(0.0);
			translation=Vec2::ZERO;
			velocity=5.0;
		}
		virtual  ~Tank(){
			//dealloc
			delete tank;//default dealloc all chialds
			//input
			Application::instance()->getInput()->removeHandler((Input::KeyboardHandler*)this);
			Application::instance()->getInput()->removeHandler((Input::MouseHandler*)this);
			Application::instance()->getInput()->removeHandler((Input::FingersHandler*)this);
		}

		void setLayer(Layer* layer,int index){
			//set into layer
			layer->addRenderable((Renderable*)tank);
			layer->addRenderable((Renderable*)tankdown);
			//indexing
			tankdown->setZ(index);
			tank->setZ(index+1);
		}

		virtual void onKeyPress(Key::Keyboard key){
			     if(key==Key::W){
					 tankdown->setAnimation(animTankUp,0.001);
					 tankdown->setPosition(Vec2(-2.5,-13));
					 translation=Vec2( 0, 1);
				 }
			else if(key==Key::S){
					 tankdown->setAnimation(animTankDown,0.001);
					 tankdown->setPosition(Vec2(-2.5,-5));
					 translation=Vec2( 0, -1);
				 }
			else if(key==Key::A){
					tankdown->setAnimation(animTankLeft,0.001);
					tankdown->setPosition(Vec2(-3.0,-15));
					 translation=Vec2( -1, 0);
				 }
			else if(key==Key::D){
					tankdown->setAnimation(animTankRight,0.001);
					tankdown->setPosition(Vec2(-3.0,-15));
					 translation=Vec2( 1, 0);
			}
		}

		virtual void onKeyDown(Key::Keyboard key){
			tank->setTranslation(translation*velocity);
		}

		virtual void onKeyRelease(Key::Keyboard key){
			tankdown->setTime(0.0);
		}

		virtual void onFingerMove(Vec3 touchPosition,Key::Finger FingerID){
			onMouseMove(touchPosition.xy());
		}
		virtual void onMouseMove(Vec2 mousePosition) {
			Vec2 alScreen(  Application::instance()->getScreen()->getWidth()/-2.0,
							Application::instance()->getScreen()->getHeight()/2.0);
			Vec2 vmouse=mousePosition.to<Math::x,Math::ny>()+alScreen;

			Vec2 vdir=tank->getPosition()-vmouse;
			float theta_rad = atan2(vdir.x,vdir.y);
			float theta_deg = Math::todeg(theta_rad) + (theta_rad > 0 ? 0 : 360);
			float offsetangle=theta_deg/10-1+9;
			tank->setFrame(animTankRotation,(offsetangle));
		}

};

#endif
